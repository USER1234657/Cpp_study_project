namespace BestComImpl
{
    void SimpleFunc();
}

namespace ProgComImpl
{
    void SimpleFunc();
}